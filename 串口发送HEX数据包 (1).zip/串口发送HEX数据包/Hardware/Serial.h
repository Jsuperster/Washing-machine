#ifndef __SERIAL_H
#define __SERIAL_H


extern uint8_t TxPacket[];
extern char RxPacket[];

void Serial_Init(void);
void sendByte(uint8_t Data);
void SerialArray( uint8_t *Array, uint16_t len);
void SerialString(uint8_t *String);
void SerialNumber(uint32_t Number, uint8_t len);
void SendPacket(void);

uint8_t GetFlag(void);

#endif
