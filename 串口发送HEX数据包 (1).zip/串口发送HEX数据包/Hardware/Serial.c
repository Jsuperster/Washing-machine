#include "stm32f10x.h"                  // Device header

uint8_t TxPacket[100];
char RxPacket[100];
uint8_t RxFlag;

void Serial_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitTypeDef USART_InitStruct;
	USART_InitStruct.USART_BaudRate = 2400;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None ;
	USART_InitStruct.USART_Mode =USART_Mode_Tx | USART_Mode_Rx ;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_StopBits =USART_StopBits_1  ;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b ;
	USART_Init(USART1,&USART_InitStruct);
	
	USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel =  USART1_IRQn ;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
	
	NVIC_Init(&NVIC_InitStruct);
	
	USART_Cmd(USART1,ENABLE);
}

uint8_t Pow(uint32_t num,uint8_t i)
{
	uint32_t a =1;
	for(int j =1;j<i;j++)
	{
		a*=10;
	}
	return (num/a)%10;
}

void sendByte(uint8_t Data)
{
	USART_SendData(USART1, Data);
	while(USART_GetFlagStatus(USART1, USART_FLAG_TXE)==RESET);
	
}

void SerialArray( uint8_t *Array, uint16_t len)
{
	uint16_t i;
	for(i =0;i<len;i++)
	{
		sendByte(Array[i]);
	}
}

void SerialString(uint8_t *String)
{
	uint8_t i;
	for(i =0;String[i]!='\0';i++)
	{
		sendByte(String[i]);
	}
}

void SerialNumber(uint32_t Number, uint8_t len)
{
	uint8_t i;
	for(i =len;i>0;i--)
	{
		uint8_t temp =Pow(Number,i);
		sendByte(temp+0x30);
	}
	SerialString("\r\n");
}

void SendPacket(void)
{
	
	sendByte(0xFF);
	SerialArray(TxPacket,4);
	sendByte(0xFE);
	
}

uint8_t GetFlag(void)
{
	if(RxFlag ==1)
	{
		RxFlag =0;
		return 1; 
	}
	else {
		return 0;
	}
}


void USART1_IRQHandler(void)
{
	static uint8_t RxState =0;
	static uint8_t num =0;
	if(USART_GetITStatus(USART1,USART_IT_RXNE)==SET)
	{
		uint8_t RxData =USART_ReceiveData(USART1);
		
		if(RxState == 0)
		{
			if(RxData =='@')
			{
				RxState =1;
				num = 0;
			}
		}
		else if(RxState ==1)
		{
			if(RxData=='\r')
			{
				RxState =2;
			}else{
				RxPacket[num] = RxData;
			    num++;
			}
			
		}
		else if(RxState ==2)
	    {
			if(RxData =='\n')
			{
				RxState =0;
				RxPacket[num] = '\0';
				RxFlag =1;
			}
		}
		USART_ClearITPendingBit(USART1,USART_IT_RXNE);
	}
		
}