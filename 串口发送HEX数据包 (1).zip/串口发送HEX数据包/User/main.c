#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "Key.h"
#include "LED.h"
#include <string.h>
#define N 100

uint8_t Keynum;


int main(void)
{
    // 将 uint16_t 修改为 uint8_t
    uint8_t a[8] = {0xAA, 0x06, 0x01, 0x98, 0x02, 0x02, 0xB2, 0x0A};
    
    // 1. 增加串口初始化
    Serial_Init();
    
    // 2. 修改长度为 8
    SerialArray(a, 8);
    
    while (1)
    {
        
    }
}